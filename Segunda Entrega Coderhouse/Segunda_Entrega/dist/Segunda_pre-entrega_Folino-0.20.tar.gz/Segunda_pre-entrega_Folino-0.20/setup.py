from setuptools import setup


setup(
    name="Segunda_pre-entrega_Folino",
    version="0.20",
    description="pre-entrega_proyecto_final",
    author="lfolino",
    author_email="leonelfolino@gmail.com",
    packages=["paquete"]
)